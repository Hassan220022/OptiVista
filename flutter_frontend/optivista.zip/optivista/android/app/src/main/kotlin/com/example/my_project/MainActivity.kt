package com.mycompany.optivista

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
