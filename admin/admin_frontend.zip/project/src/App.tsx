import React from 'react';
import { DashboardView } from './components/admin/dashboard/DashboardView';
import { ProductList } from './components/admin/products/ProductList';
import { OrderList } from './components/admin/orders/OrderList';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white border-b border-gray-200">
        <div className="px-4 mx-auto">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex items-center flex-shrink-0">
                <h1 className="text-xl font-bold text-gray-900">Admin Dashboard</h1>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main>
        <DashboardView />
        <ProductList />
        <OrderList />
      </main>
    </div>
  );
}

export default App;