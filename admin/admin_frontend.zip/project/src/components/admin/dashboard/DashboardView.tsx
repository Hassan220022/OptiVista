import React from 'react';
import { BarChart3, Users, Package, ShoppingCart } from 'lucide-react';
import { StatCard } from './StatCard';

const stats = [
  { title: 'Total Sales', value: '$12,345', icon: BarChart3, change: '+12%' },
  { title: 'Active Users', value: '1,234', icon: Users, change: '+3%' },
  { title: 'Products', value: '345', icon: Package, change: '+5%' },
  { title: 'Pending Orders', value: '23', icon: ShoppingCart, change: '-2%' },
];

export function DashboardView() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <StatCard key={stat.title} {...stat} />
        ))}
      </div>
    </div>
  );
}